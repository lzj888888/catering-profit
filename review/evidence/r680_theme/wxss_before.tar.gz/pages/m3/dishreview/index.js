// pages/m3/dishreview/index.js —— M3.33 单品毛利复盘（只读排名页）
//
// 数据：getDishReview() 读 external_sales_daily（堂食+外卖）+ shop_cost_card → 服务端排名（§2.4 口径写死）。
// 🔴 只读：本页只调 getDishReview，**绝不**写成本卡 / M1 / 销量。
// 🔴 付费墙：看复盘才拦（m3_dishreview）。getDishReview 返回 FEATURE_LOCKED ⇒ openPaywall('dishreview')；
//    导入可免费保存（见 terms.paywall.dishreview.content）。
// 🔴 两来源分开呈现：堂食榜 + 外卖榜（按平台分块）。红线 18：不默认外卖=0，无数据 ⇒ 空态。
// 🔴 未匹配菜品单列 + 「去映射」入口（红线 17：不静默归零）。
// 🔴 v1.7 C-5：零价高销量行（amount=0 且 qty>0）标「口味询问类 SKU，不计营收」，不剔除。
// 毛利率阈值用户自定义（默认 30 仅占位，不做成警戒线 —— R128 同族）。
const api = require('../../../utils/api.js');
const ui = require('../../../utils/ui.js');
const { openPaywall } = require('../../../utils/paywall.js');
const { TERMS } = require('../../../miniprogram/i18n/terms.js');
// R260：菜名映射「建议卡」纯函数（**只预选、不落库**，规范 v1.9 §0 D32）
const { suggestCardIndex, BATCH_CHUNK } = require('../../../utils/dishMapSuggest.js');
// R299：云函数出参 `truncated` 的**可见降级**唯一谓词（单源）。
//   为什么：`dataAdapter.js::listAll` 明文要求调用方把「已到读取上限、可能不全」透传到**用户面前**
//   （可见降级），服务端照做了、前端此前零消费 ⇒ 超上限时静默少行。见 `utils/dataHealth.js` 头注。
const dh = require('../../../utils/dataHealth.js');
// R615 M3 决策台：把复盘出参组织成「该动哪道菜」（纯函数，零云函数改动）
const M3D = require('../../../utils/m3Decision.js');
// 🔴 R307：占比拆分参考榜（纯函数）—— 外卖销量拿不到时的**轻量补位**，见模块头注（含三条铁律）
const { splitRank, MAX_ROWS, qtyText } = require('../../../utils/shareSplit.js');

const fenYuan = (fen) => (Number(fen) || 0) / 100;
const fmtYuan = (fen) => fenYuan(fen).toFixed(2);
const fmtPct = (p) => (Number(p) || 0).toFixed(2) + '%';
// R606-bis：行级可编辑循环的稳定身份键工厂（与 month/input.js 同款）。
//   wx:for 用位置键 + 每次按键整体重赋值数组 ⇒ 原生 <input> 按下标复用 DOM ⇒ 节点身份错位、
//   表现为「框填不进/丢焦点」。rid 仅渲染层用，提交时由 onSplitCalc 重建干净 payload（不含 rid）。
const _ridPrefix = 'k' + Date.now().toString(36) + '_';
let _ridSeq = 0;
function ensureRid(r) {
  if (!r) r = {};
  if (!r.rid) r.rid = _ridPrefix + (_ridSeq++).toString(36);
  return r;
}

Page({
  data: {
    t: {
      reviewTitle: TERMS.card.reviewTitle,
      reviewAfterFact: TERMS.card.reviewAfterFact,
      // 🔴 R307：占比拆分参考榜（估算）—— 逐条列举，漏登记 = 页面静默空白（守 check_page_terms）
      splitTitle: TERMS.card.splitTitle,
      splitIntro: TERMS.card.splitIntro,
      splitOrderLabel: TERMS.card.splitOrderLabel,
      splitNoOrder: TERMS.card.splitNoOrder,
      splitPickPh: TERMS.card.splitPickPh,
      splitPctPh: TERMS.card.splitPctPh,
      splitAdd: TERMS.card.splitAdd,
      splitCalc: TERMS.card.splitCalc,
      splitResultTitle: TERMS.card.splitResultTitle,
      splitNote: TERMS.card.splitNote,
      splitQty: TERMS.card.splitQty,
      splitContrib: TERMS.card.splitContrib,
      splitLossTag: TERMS.card.splitLossTag,
      splitTotal: TERMS.card.splitTotal,
      splitErrNoRows: TERMS.card.splitErrNoRows,
      splitErrDup: TERMS.card.splitErrDup,
      splitErrPct: TERMS.card.splitErrPct,
      splitErrSum: TERMS.card.splitErrSum,
      splitErrNoPrice: TERMS.card.splitErrNoPrice,
      reviewDineIn: TERMS.card.reviewDineIn,
      reviewTakeaway: TERMS.card.reviewTakeaway,
      reviewTakeawayEmpty: TERMS.card.reviewTakeawayEmpty,
      reviewZeroAmount: TERMS.card.reviewZeroAmount,
      reviewRankTitle: TERMS.card.reviewRankTitle,
      reviewDish: TERMS.card.reviewDish,
      reviewQty: TERMS.card.reviewQty,
      reviewRevenue: TERMS.card.reviewRevenue,
      reviewCost: TERMS.card.reviewCost,
      reviewGross: TERMS.card.reviewGross,
      // A8：免费档说明 + 升级入口（wxml 用到就必须在这里登记，否则真机静默空白 —— 守卫 page-terms P2-1）
      reviewFreeTitle: TERMS.card.reviewFreeTitle,
      reviewFreeBody: TERMS.card.reviewFreeBody,
      reviewFreeBtn: TERMS.card.reviewFreeBtn,
      reviewFreeRankTitle: TERMS.card.reviewFreeRankTitle,
      // R259：外卖毛利率的**口径说明** —— 李老师 2026-10-10 裁定指标名保持「毛利率」，
      //   所以防误导不靠改名，靠**同屏把差在哪讲清**（外卖侧金额是平台侧金额、非商家到手）。
      reviewTakeawayMarginNote: TERMS.card.reviewTakeawayMarginNote,
      reviewMargin: TERMS.card.reviewMargin,
      // R615 M3 决策台（wxml 用到就必须登记，漏了静默空白）
      decTitle: TERMS.card.decTitle,
      decSub: TERMS.card.decSub,
      decMedianLine: TERMS.card.decMedianLine,
      decKindCut: TERMS.card.decKindCut,
      decKindRaise: TERMS.card.decKindRaise,
      decKindBundle: TERMS.card.decKindBundle,
      decKindPush: TERMS.card.decKindPush,
      decCutText: TERMS.card.decCutText,
      decRaiseText: TERMS.card.decRaiseText,
      decBundleText: TERMS.card.decBundleText,
      decPushText: TERMS.card.decPushText,
      decInsFew: TERMS.card.decInsFew,
      decInsCoverage: TERMS.card.decInsCoverage,
      decInsNoDishes: TERMS.card.decInsNoDishes,
      decInsNoMargin: TERMS.card.decInsNoMargin,
      decFreeNote: TERMS.card.decFreeNote,
      reviewThreshold: TERMS.card.reviewThreshold,
      reviewThresholdHint: TERMS.card.reviewThresholdHint,
      reviewUnmatched: TERMS.card.reviewUnmatched,
      reviewUnmatchedHint: TERMS.card.reviewUnmatchedHint,
      reviewGoMap: TERMS.card.reviewGoMap,
      reviewGoCard: TERMS.card.reviewGoCard,
      // R255：菜名映射写侧（关联到成本卡 / 解除）
      reviewMapPick: TERMS.card.reviewMapPick,
      reviewMapTitle: TERMS.card.reviewMapTitle,
      reviewMapHint: TERMS.card.reviewMapHint,
      reviewMapEmpty: TERMS.card.reviewMapEmpty,
      reviewMapLinked: TERMS.card.reviewMapLinked,
      reviewMapUnlink: TERMS.card.reviewMapUnlink,
      reviewMapNoCard: TERMS.card.reviewMapNoCard,
      reviewMapShortCard: TERMS.card.reviewMapShortCard,
      // R264 覆盖率明示 + 行内「去建卡」（第三处登记）
      reviewCoverage: TERMS.card.reviewCoverage,
      reviewCoverageHint: TERMS.card.reviewCoverageHint,
      // R272：C 档覆盖率口径说明（wxml:27 引用，此前漏注册 ⇒ 真机静默空白）
      reviewCoverageCHint: TERMS.card.reviewCoverageCHint,
      reviewNewCard: TERMS.card.reviewNewCard,
      // R272：自助餐（快餐=随便吃）人均食材成本块 —— 下方 wxml 用 t.reviewBuffet*，本页 t:{} 此前漏注册 ⇒ 真机标签空白（静默空白 bug），此处补齐
      reviewBuffetTitle: TERMS.card.reviewBuffetTitle,
      reviewBuffetRevenue: TERMS.card.reviewBuffetRevenue,
      reviewBuffetMeals: TERMS.card.reviewBuffetMeals,
      reviewBuffetPerCapitaPrice: TERMS.card.reviewBuffetPerCapitaPrice,
      reviewBuffetPerCapitaCost: TERMS.card.reviewBuffetPerCapitaCost,
      reviewBuffetNoCost: TERMS.card.reviewBuffetNoCost,
      reviewBuffetGrossMargin: TERMS.card.reviewBuffetGrossMargin,
      reviewBuffetHint: TERMS.card.reviewBuffetHint,
      // R272b：行业基准带（网上平均数据）
      reviewBuffetBenchTitle: TERMS.card.reviewBuffetBenchTitle,
      reviewBuffetBenchLow: TERMS.card.reviewBuffetBenchLow,
      reviewBuffetBenchMid: TERMS.card.reviewBuffetBenchMid,
      reviewBuffetBenchHigh: TERMS.card.reviewBuffetBenchHigh,
      reviewBuffetBenchHint: TERMS.card.reviewBuffetBenchHint,
      reviewBuffetActual: TERMS.card.reviewBuffetActual,
      // R260 批量关联（第三处登记）
      reviewBatchEnter: TERMS.card.reviewBatchEnter,
      reviewBatchExit: TERMS.card.reviewBatchExit,
      reviewBatchHint: TERMS.card.reviewBatchHint,
      reviewBatchSuggest: TERMS.card.reviewBatchSuggest,
      reviewBatchSave: TERMS.card.reviewBatchSave,
      reviewBatchNone: TERMS.card.reviewBatchNone,
      reviewBatchSaving: TERMS.card.reviewBatchSaving,
      reviewBatchDone: TERMS.card.reviewBatchDone,
      reviewEmpty: TERMS.card.reviewEmpty,
      // R252：已导入账单「查看 + 清除」
      reviewBillsTitle: TERMS.card.reviewBillsTitle,
      reviewBillsHint: TERMS.card.reviewBillsHint,
      reviewBillsEmpty: TERMS.card.reviewBillsEmpty,
      reviewBillsBill: TERMS.card.reviewBillsBill,
      reviewBillsDish: TERMS.card.reviewBillsDish,
      reviewBillsUnit: TERMS.card.reviewBillsUnit,
      reviewBillsRows: TERMS.card.reviewBillsRows,
      reviewBillsQty: TERMS.card.reviewBillsQty,
      reviewBillsCleared: TERMS.card.reviewBillsCleared,
      reviewBillsClear: TERMS.card.reviewBillsClear,
      reviewBillsClearAll: TERMS.card.reviewBillsClearAll,
      reviewBillsClearedNone: TERMS.card.reviewBillsClearedNone,
      reviewTotals: TERMS.card.reviewTotals,
      reviewTotalQty: TERMS.card.reviewTotalQty,
      reviewTotalRevenue: TERMS.card.reviewTotalRevenue,
      reviewTotalCost: TERMS.card.reviewTotalCost,
      reviewTotalGross: TERMS.card.reviewTotalGross,
      // 🔴 R451：两款毛利率口径并列提示（terms.js 同名键，逐键登记——漏登记 ⇒ 真机静默空白）
      reviewTwoMarginNote: TERMS.card.reviewTwoMarginNote,
      // 🔴 R281 O2：首屏重构新增键（第三处登记 —— 漏登记 ⇒ 真机静默空白）
      reviewTodoPre: TERMS.card.reviewTodoPre,
      reviewTodoSuf: TERMS.card.reviewTodoSuf,
      reviewTodoBtn: TERMS.card.reviewTodoBtn,
      reviewMoreTitle: TERMS.card.reviewMoreTitle,
      reviewMoreOpen: TERMS.card.reviewMoreOpen,
      reviewMoreClose: TERMS.card.reviewMoreClose,
      reviewDataTitle: TERMS.card.reviewDataTitle,
      cur: '¥',
      loading: TERMS.ui.loading,
      // R299：数据截断的可见降级文案（单源 TERMS.ui.dataTruncated）
      dataTruncated: TERMS.ui.dataTruncated,
      // 🔴 R301：统计月份选择器的标签（期间口径必须让用户看得见）
      reviewMonthPick: TERMS.card.reviewMonthPick,
    },
    loading: true,
    locked: false,
    // 🔴 R301：本榜的**统计月份**（YYYY-MM）。为什么必须有：契约要求 `getDishReview` 按
    //   `biz_date_from/to` 取数，而在此之前实现从不过滤 ⇒ 榜是**跨月累计**却按"当前月"呈现。
    //   注意它与 `curMonth` 是**两件事**：`curMonth` 只是「进入页面那天是几月」（一次性，此后不更新），
    //   而快照提示的比对基准**必须是下面这个 `month`**（R547/M7：改前误用 curMonth ⇒ 看历史月时全表误标）。
    //   `month` 才是**数据统计期间**。二者在页面上必须分开讲清（R299 §`snapshot_month` 同一条纪律）。
    month: '',
    // 期间标注文案（由云端回的 `range` 如实生成；**不许前端猜**）
    rangeText: '',
    // R299：本页是否有**已被服务端标记为「已达读取上限」**的读取（复盘榜 / 成本卡 / 账单任一）。
    //   为 true ⇒ 页面顶部显示可见降级提示 —— 见 utils/dataHealth.js 头注（为什么不能静默）。
    truncated: false,
    // 🔴 R281 O2：两个折叠区默认**收起** —— 首屏只留「未匹配待办条 + 堂食榜 + 外卖榜」。
    //   覆盖率 / 自助餐 / 阈值 / 已关联 / 账单 只是**折层级，不删**（守 R264/R272/R255/R252）。
    moreOpen: false,
    dataOpen: false,
    threshold: 30,           // 用户自定义阈值（默认占位值，非警戒线）
    thresholdInput: '30',
    curMonth: '',
    dineIn: [],              // 堂食排行（已预处理展示字段）
    decision: null,          // R615：该动哪道菜（null = 还没算）
    takeaway: null,          // 外卖：null=空态；否则 [{ platform, platformName, ranked, totals }]
    unmatched: [],           // 未匹配菜品
    totals: null,
    empty: false,
    // 🔴 R307：占比拆分参考榜（**估算**）。只在空态渲染 ⇒ 天然不与实测榜混排（R306 铁律①）。
    //   `splitCards` 与 `loadCards()` 同一次 `getCostCard({})` 派生，**不新增读接口**。
    splitOpen: false,
    splitCards: [],        // [{ code, name, priceFen, costFen }]
    splitOptions: [],      // picker 显示名
    splitRows: [],         // [{ cardIdx, name, pctText }]
    splitOrderCount: 0,    // 本月外卖有效订单数（来自 M1 已落库的 sub_items[].qty）
    splitHasOrder: false,
    splitResult: null,     // 算完才赋值；null ⇒ 不渲染结果区
    splitErr: '',          // 人话（按 code 查 terms）
    splitMax: 5,
    // R252：已导入账单列表（getSalesBills 读侧；与复盘榜同源集合，但**独立读取**）
    bills: [],
    billsSummary: null,
    clearing: false,
    // ===== R255：菜名映射写侧 =====
    cardOptions: [],      // picker 的 range（成本卡名）
    cardCodes: [],        // 与 cardOptions 同序的 card_code（picker 只给索引 ⇒ 必须自己对齐）
    // R262：「卡不够挂」引导（未匹配数 − 卡数；>0 才显示，见 load() 内 shortCardText）
    shortCardGap: 0,
    shortCardText: '',
    // R264：覆盖率明示（共 N 道 / 已算 M 道 / 覆盖 X% 营收；见 load() 内 coverageText）
    coverageCount: 0,
    coverageMatched: 0,
    coveragePct: 0,
    coverageText: '',
    // R272：覆盖率 C 档 + 自助餐人均食材成本（见 load() 内 coverageCText / buffet_*）
    coverageC_pct: 0,
    coverageCText: '',
    buffetMeals: 0,
    buffet_revenueText: '',
    buffet_perCapitaPriceText: '',
    buffet_perCapitaCostText: '',
    buffet_grossMarginText: '',
    buffet_hasCostInput: false,
    // R272b：行业基准带（网上平均数据，对照用）
    buffet_benchLowText: '',
    buffet_benchMidText: '',
    buffet_benchHighText: '',
    buffet_rateLowPct: 0,
    buffet_rateMidPct: 0,
    buffet_rateHighPct: 0,
    buffet_actualRateText: '',
    buffet_flagClass: '',
    mappings: [],         // 已关联菜品（来自 getDishReview 出参 mapping）+ 展示字段
    // ===== R260 批量关联（规范 v1.9）=====
    batchMode: false,     // 批量模式：行的选择只记在本机，点「保存全部关联」才提交
    batchCount: 0,        // 已选行数（按钮上的计数）
    batchSaving: false,   // 提交中（防连点）
    mappingBusy: false,   // 写操作进行中（防连点重复提交）
    // A8：'free' = 只给销量榜 Top10 + 覆盖率 + 未匹配；'full' = 完整毛利排行
    tier: '',
    freeRankedTotal: 0,
  },

  onLoad() { this._shown = false; this.init(); },
  // 🔴 R299（缺陷 D3）：「去建卡 / 去映射」在本页是 `navigateTo` 跳走再回来（R264 专门设计的闭环），
  //   而本页 `enablePullDownRefresh: false`（无下拉刷新）、旧 onShow 又**只在 locked 时**重载
  //   ⇒ 返回后页面全然不刷新：刚建的卡不进关联 picker、刚挂的菜不进榜、unmatched 也不减少
  //   ⇒ 用户会以为「卡没建上 / 关联失败」并重复操作。
  //   本页是**只读页**（零未保存输入）⇒ 返回时重载是安全且期待的。
  //   对照 `subpkg/biz/card/index.js:122` 同类只读页即 `onShow(){this.load()}` —— 说明这是遗漏，不是设计选择。
  //   首次进入不重复拉：onLoad 的 init() 已经在拉，`_shown` 此时仍为 false。
  onShow() {
    if (this.data.locked) { this.init(); return; }   // 从付费弹窗返回后重试
    if (this._shown) this.load();
    this._shown = true;
  },

  async init() {
    try {
      await api.ensureShop();
      ui.setTitle(TERMS.card.reviewTitle);
      this.setData({ curMonth: ui.nowMonth(), month: ui.nowMonth() });
      await this.load();
    } catch (e) {
      this.setData({ loading: false });
      // 🔴 A8（2026-11-05）：云端**已改为两层出参**，正常不再返回 FEATURE_LOCKED。
      //   此分支保留仅作兜底（旧版云端 / 灰度期），不再是主路径 —— 别据它认为本页仍是整页锁。
      if (e && e.code === 'FEATURE_LOCKED') {
        this.setData({ locked: true });
        openPaywall('dishreview', { shopId: (getApp().globalData && getApp().globalData.shop_id) || '' });
        return;
      }
      api.toastError(e);
    }
  },

  // A8：免费档页面内的升级入口（榜单下方的「看完整毛利排行」按钮）
  goUpgrade() {
    openPaywall('dishreview', { shopId: (getApp().globalData && getApp().globalData.shop_id) || '' });
  },

  // 预处理一行排行为展示字段（堂食/外卖共用；zeroAmount 仅外卖）
  fmtRanked(x) {
    const snapMonth = x.snapshot_month || '';
    // 🔴 R547（M7）：比对基准必须是**本次统计月**（`month`），不是「今天所在的月」。
    //   提示语的含义是「这张卡的成本是 X 月的快照，比你在看的这个月旧」——
    //   改前拿 `curMonth`（进入页面时的真实当月，之后再没更新过）作基准 ⇒ 两个后果：
    //     ① 看任何一个**历史月**的榜，全表每一行都误挂「该卡成本为 X 月快照」
    //        （而 X 恰恰就是这个统计月 ⇒ 成本一点都不过期，纯噪音，老板会开始无视这条提示）；
    //     ② 反过来，切到未来月/月初跨月时基准漂移 ⇒ 真过期的卡（上月建的）反而不提示。
    //   基准跟着「你在看哪个月」走，才与文案语义一致。
    const dataMonth = this.data.month || this.data.curMonth;
    const isOld = !!snapMonth && !!dataMonth && snapMonth !== dataMonth;
    return {
      // 🔴 R299（缺陷 D1）：`dishKey` **必须带出来** —— 覆盖率「共 N 道」必须按**菜品身份**去重，
      //   而本行的 `name` 是**成本卡名**（service.js:95 `card.name || dishKey`），与未匹配行的
      //   `name`（service.js:86 `dishKey`，**菜名**）**不是同一个命名空间**。
      //   此前覆盖率把两者塞进同一个 Set ⇒ 多张卡挂到同一张卡时「共 N 道」少算、卡名与菜名
      //   碰巧同名时两个数一起错（用户可见的错数，见 evidence FINDINGS §2）。
      dishKey: x.dish_key || x.name || '',
      name: x.name || x.dish_key,
      qty: x.qty,
      revenueText: fmtYuan(x.amountFen),
      // 🔴 R264：覆盖率要按**金额**算 ⇒ 数值必须带到展示层（`revenueText` 是字符串，不能相减）
      amountFen: x.amountFen || 0,
      // 🔴 A8（2026-11-05）：免费档后端**不下发** totalCostFen / grossFen / marginPct。
      //   这里必须判 `== null` 显示「—」，**绝不能走 fmtYuan(undefined)** ——
      //   那会渲染成「0.00」，让老板以为「成本是 0、毛利等于营收」，比不显示更坏（红线 18 同款）。
      costText: x.totalCostFen == null ? '—' : fmtYuan(x.totalCostFen),
      grossText: x.grossFen == null ? '—' : fmtYuan(x.grossFen),
      marginPct: x.marginPct == null ? null : x.marginPct,
      marginText: x.marginPct == null ? '—' : fmtPct(x.marginPct),
      hasMargin: x.grossFen != null,
      snapshotNote: isOld ? TERMS.card.reviewSnapshotOf(snapMonth) : '',
      zeroAmount: !!x.zeroAmount,   // v1.7 C-5：口味询问类 SKU
      below: false,
    };
  },

  fmtTotals(t) {
    return t ? {
      qty: t.qty,
      revenueText: fmtYuan(t.amountFen),
      // A8：免费档的合计只回数量口径（毛利合计 = 加工结论，付费才有）⇒ 缺失一律「—」
      costText: t.costFen == null ? '—' : fmtYuan(t.costFen),
      grossText: t.grossFen == null ? '—' : fmtYuan(t.grossFen),
      hasMargin: t.grossFen != null,
      // 🔴 R251：`unmatchedCount` 必须带出来 —— 它是**判「平台块为什么是空的」的唯一准确依据**
      //   （前端**不许**自己猜：拿 qty>0 当判据会把「全 0 份的菜」误判成账单级）。
      unmatchedCount: t.unmatchedCount || 0,
    } : null;
  },

  async load() {
    this.setData({ loading: true });
    // 🔴 R301：**必须传**契约入参 `biz_date_from` / `biz_date_to`（月 → 区间走 `utils/ui.js::monthRange` 单源）。
    //   不传 ⇒ 云端不过滤 ⇒ 榜**跨月累计**（正是 R301 修的缺陷）⇒ 由守卫钉住"必须传"（见 NOTE 的判据）。
    //   `month` 缺省自愈为当前月：与 `init()` 的默认**同一个口径**（只此一处兜底，不新增语义），
    //   避免"某条路径没先 init 就 load"时静默退回**不过滤**（那会把跨月累计这个缺陷放回来）。
    const month = this.data.month || ui.nowMonth();
    const rng = ui.monthRange(month);
    const d = await api.call('getDishReview', { biz_date_from: rng.from, biz_date_to: rng.to });
    // 🔴 R301 期间标注：云端**如实回** `range{from,to,days}` ⇒ 有区间就报
    //   「本榜统计 YYYY-MM，共 N 天有数据」（N 直接把"这个月只有 7 天数据"暴露出来）；
    //   没有区间（旧客户端 / 只给一端 ⇒ 云端不过滤）就**明说"不是单月"**，**绝不假装是本月**。
    const rg = (d && d.range) || {};
    // 🔴 R574 / #110：云端额外如实回了 `has_interval` / `has_unknown` / `covered_days`
    //   ⇒ 三条文案分支（优先级：含汇总表 > 含旧版导入 > 常规）。
    //   **前端不许自己推粒度** —— 判据全在云端 `coverageStats`，前端只负责把它讲成人话。
    //   典型场景：堂食 7 天汇总表 + 外卖 7 天逐日，两栏都显示"7"，但前者其实是"7 天记在 1 天"。
    let rangeText;
    if (rg.from && rg.to) {
      if (rg.has_interval) rangeText = TERMS.card.reviewRangeSpan(month, rg.covered_days || rg.days || 0);
      else if (rg.has_unknown) rangeText = TERMS.card.reviewRangeLegacy(month, rg.days || 0);
      else rangeText = TERMS.card.reviewRangeOf(month, rg.days || 0);
    } else {
      rangeText = TERMS.card.reviewRangeAll(rg.days || 0);
    }
    // 🔴 R299（缺陷 D2）：消费服务端 `truncated`（可见降级）。见 utils/dataHealth.js 头注。
    this._setTrunc('review', dh.isTruncated(d));
    // 🔴 R255：成本卡列表（「关联」picker 用）。**必须在这里先拉** —— 下面构造
    //   unmatched（显示已关联卡名）与 mappings（显示卡名）都要用它做 code→name。
    const { cardOptions, cardCodes, nameByCode, splitCards, truncated: cardsTruncated } = await this.loadCards();
    this._setTrunc('cards', cardsTruncated);
    // R307：占比估算的候选卡（与「关联」picker 同源，不额外读库）
    this.setData({ splitCards, splitOptions: (splitCards || []).map((c) => c.name) });

    // 🔴 A8（2026-11-05）：免费档云端只回 `free_top`（销量 Top N，**不含成本/毛利字段**），
    //   付费档回完整 `dine_in`。这里只是**换数据源**，下游覆盖率/未匹配/映射逻辑一行不动 ——
    //   免费档拿到的仍是「销量 + 营收」，够算覆盖率，也够让老板看出「我这 20 道菜只算全了 3 道」。
    const isFree = (d && d.tier) === 'free';
    const dineIn = (((isFree ? d.free_top : d.dine_in) || [])).map((x) => this.fmtRanked(x));

    // 🔴 R249-B（附带发现，与 is_deleted 同轮修）：外卖的「未匹配菜品」**只**嵌在
    //   `takeaway.by_platform[p].unmatched` 里，而前端**从不读**它（只读顶层 `d.unmatched`，
    //   而顶层那份是 `buildDishInReview` 的产物 = **仅堂食**）⇒ 外卖路径下
    //   「红线 17：不静默归零」**未落地**：外卖商品全部匹配不上成本卡时，
    //   外卖榜区块因 `ranked.length === 0` 连表头都不渲染，只留一个**空标题**，
    //   用户可见 =「导了但什么都没变」（正是 R249 报障现场的第二层）。
    //   修法：按菜名合并（堂食 + 各外卖平台）后并入下方同一张「未匹配菜品」表 ——
    //   复用既有文案 `reviewUnmatched/reviewUnmatchedHint/reviewGoMap` 与既有渲染块
    //   ⇒ **零新增可见文案**（不必动术语三处同步面）。同名单跨平台只出一行、qty/金额相加。
    const unmatchedMap = new Map();
    const pushUnmatched = (x, platName) => {
      const nm = x.name || x.dish_key || '';
      if (!nm) return;
      // 🔴 R255：必须保留**原始 dish_key** —— 写侧映射的键就是它（`platform + '|' + dish_key`）。
      //   unmatched 行里 name 与 dish_key 目前同源（service.js 两字段都写 dishKey），
      //   但显式带 dish_key 才不依赖这个巧合：哪天后端给 name 换成人读名，这里不至于失配。
      const cur = unmatchedMap.get(nm) || { name: nm, dishKey: x.dish_key || nm, qty: 0, amountFen: 0, platforms: new Set() };
      cur.qty += x.qty || 0;
      cur.amountFen += x.amountFen || 0;
      if (platName) cur.platforms.add(platName);
      unmatchedMap.set(nm, cur);
    };
    // 🔴 R251：合并时**必须带上来源平台** —— 否则跨平台合并成一张表后，
    //   用户看不出某道菜来自淘宝还是京东（真机报障：「京东我也导入了，可是没看到 JD 字样」）。
    //   平台名走既有单源 `TERMS.card.reviewPlatformNames`（+ 堂食名 `reviewDineIn`），**零新增文案**。
    const PLAT_NAMES = TERMS.card.reviewPlatformNames;
    (d.unmatched || []).forEach((x) => pushUnmatched(x, TERMS.card.reviewDineIn));
    if (d.takeaway && d.takeaway.by_platform) {
      for (const p of Object.keys(d.takeaway.by_platform)) {
        const pn = PLAT_NAMES[p] || p;
        (((d.takeaway.by_platform[p] || {}).unmatched) || []).forEach((x) => pushUnmatched(x, pn));
      }
    }
    // 🔴 R255：dish_key → card_code（来自 getDishReview 出参 mapping）
    //   用途①：未匹配行显示「已关联：X」（映射写了但读侧没生效 ⇒ 卡被删了或 platform 不匹配，
    //           此时用户看到的仍是未匹配，最容易困惑）；
    const mapByDishKey = new Map();
    for (const m of (d.mapping || [])) {
      if (!m || !m.dish_key || !m.card_code) continue;
      mapByDishKey.set(m.dish_key, m.card_code);
    }
    // 🔴 R261：**按营收降序** —— 真实数据下未匹配清单有 51 行（外卖商品表）/ 270 行（堂食菜品表），
    //   而后端返回的是"首见顺序"。按首见顺序排，用户得逐行读才知道**哪道菜影响最大**；
    //   降序后大头永远在最上面，批量关联（R260）也就能先处理真正值得处理的那批。
    //   ⚠️ 排序必须在 `.map()` **之前**：map 之后的行里只有 `amountText`（字符串），
    //      拿它做减法排序会得到 NaN ⇒ 顺序不动（**静默失效**，页面看着正常）。
    //   ⚠️ 同额时按份数、再按菜名兜底 ⇒ **顺序稳定**（否则两次 load 顺序抖动，用户以为数据变了）。
    const unmatchedSorted = Array.from(unmatchedMap.values()).sort((a, b) =>
      (b.amountFen - a.amountFen) || (b.qty - a.qty) || String(a.name).localeCompare(String(b.name)));
    const unmatched = unmatchedSorted.map((x) => ({
      name: x.name,
      dishKey: x.dishKey,
      mappedCardName: nameByCode[mapByDishKey.get(x.dishKey) || ''] || '',
      qty: x.qty,
      amountText: fmtYuan(x.amountFen),
      platformText: Array.from(x.platforms).join(' / '),
      // 🔴 R251：0 元高份数行 = v1.7 C-5 的「口味询问类 SKU」（如「来点辣椒吗」43 份 / 0 元）。
      //   该标记原先**只在 `ranked` 分支里打**（service.js::buildTakeawayReview），
      //   一旦这行没有成本卡、掉进 `unmatched`，标记就丢了 ⇒ 43 份 0 元混在未匹配里，
      //   把读者对「份数」的观感推高。此处按同一口径（amount 0 且 qty>0）在前端补回，复用既有文案。
      zeroAmount: x.amountFen === 0 && x.qty > 0,
    }));
    const totals = this.fmtTotals(d.totals);

    // ===== R615 M3 决策台：该动哪道菜 =====
    //   分界线用本店当月**中位数**；菜数 <10 或营收覆盖 <60% 只给原因、不给动作；
    //   免费档后端本就不下发毛利 ⇒ 只给销量结构，绝不拿「营收 − 0 成本」凑毛利。
    const decRows = ((isFree ? d.free_top : d.dine_in) || []).map((x) => ({
      name: x.name || x.dish_key || '',
      qty: Number(x.qty) || 0,
      amountFen: Number(x.amountFen) || 0,
      totalCostFen: x.totalCostFen == null ? null : Number(x.totalCostFen),
      grossFen: x.grossFen == null ? null : Number(x.grossFen),
    }));
    const decUnmatchedAmount = unmatchedSorted.reduce((s, x) => s + (Number(x.amountFen) || 0), 0);
    const decRaw = M3D.buildDishDecision({
      rows: decRows, unmatchedAmountFen: decUnmatchedAmount, tier: isFree ? 'free' : 'full',
    });
    const TT = this.data.t;
    const decFill = (tpl, map) => String(tpl || '').replace(/\{(\w+)\}/g,
      (m, k) => (map[k] == null ? '' : String(map[k])));
    const decInsText = !decRaw.insufficient ? '' : decFill(
      decRaw.reason === 'few_dishes' ? TT.decInsFew
        : decRaw.reason === 'low_coverage' ? TT.decInsCoverage
          : decRaw.reason === 'no_dishes' ? TT.decInsNoDishes : TT.decInsNoMargin,
      { n: decRaw.dishCount, pct: decRaw.coveragePct == null ? '—' : decRaw.coveragePct });
    const decActions = (decRaw.actions || []).map((a) => {
      if (a.kind === 'cut') return { kind: a.kind, kindText: TT.decKindCut, name: a.name,
        text: decFill(TT.decCutText, { loss: fmtYuan(a.lossFen), cost: fmtYuan(a.costFen) }) };
      if (a.kind === 'raise') return { kind: a.kind, kindText: TT.decKindRaise, name: a.name,
        text: decFill(TT.decRaiseText, { margin: a.marginPct, gain: fmtYuan(a.gainFen) }) };
      if (a.kind === 'bundle') return { kind: a.kind, kindText: TT.decKindBundle, name: a.name,
        text: decFill(TT.decBundleText, { gross: fmtYuan(a.grossFen) }) };
      return { kind: a.kind, kindText: TT.decKindPush, name: a.name,
        text: decFill(TT.decPushText, { gross: fmtYuan(a.grossFen), share: a.sharePct == null ? '—' : a.sharePct }) };
    });
    const decision = {
      insufficient: !!decRaw.insufficient,
      insufficientText: decInsText,
      free: !!decRaw.free,
      freeNote: decRaw.free ? TT.decFreeNote : '',
      medianLine: decRaw.insufficient ? '' : decFill(TT.decMedianLine, {
        qty: decRaw.medianQty == null ? '—' : decRaw.medianQty,
        margin: decRaw.medianMarginPct == null ? '—' : decRaw.medianMarginPct,
      }),
      actions: decActions,
    };

    // ===== R255：「已关联菜品」列表（**解除入口**）=====
    //   为什么必须有这一块：**关联成功后该菜会从 unmatched 变 ranked** ⇒ 未匹配清单里没有它了。
    //   若不给独立的解除入口，用户既改不了也删不掉 ⇒ 挂错一次卡就是死结（A1 锚点的反面）。
    //   `platform` 为空 = 跨所有平台生效 ⇒ 不显示平台名（不为此新增文案）。
    const mappings = (d.mapping || []).map((m) => ({
      dishKey: m.dish_key,
      platformText: m.platform ? (PLAT_NAMES[m.platform] || m.platform) : '',
      cardCode: m.card_code,
      cardName: nameByCode[m.card_code] || m.card_code,
    }));

    // 外卖：按平台分块（无数据 ⇒ null 空态，不默认 0）
    // 🔴 R251：每块必须带出「合计 + 未匹配数 + 空榜成因」，否则榜为空时页面上只剩一个**光标题**
    //   （李老师 2026-10-09 真机报障：「又有京东又有淘宝…是不是混乱了」）。
    //   成因判据用后端已算好的 `totals.unmatchedCount`，**不用前端猜**：
    //     unmatchedCount > 0 ⇒ 有菜品行但一张卡都没匹配上；
    //     unmatchedCount = 0 且 ranked 空 ⇒ 该平台只进了「账单级」行（dish_key 为空，被 rankReview 跳过）。
    const names = TERMS.card.reviewPlatformNames;
    let takeaway = null;
    if (d.takeaway && d.takeaway.by_platform) {
      takeaway = Object.keys(d.takeaway.by_platform).map((p) => {
        const b = d.takeaway.by_platform[p];
        const ranked = (b.ranked || []).map((x) => this.fmtRanked(x));
        const totals = this.fmtTotals(b.totals);
        const unmatchedCount = (totals && totals.unmatchedCount) || 0;
        return {
          platform: p,
          platformName: names[p] || p,
          ranked,
          totals,
          unmatchedCount,
          emptyReason: ranked.length ? ''
            : (unmatchedCount > 0 ? TERMS.card.reviewPlatformAllUnmatched : TERMS.card.reviewPlatformBillOnly),
        };
      });
    }

    // ===== R262：「卡不够挂」显式引导 =====
    //   真机实证：3 张卡 vs 51 道外卖菜 ⇒ 每行 picker 只有这 3 张可选；界面既不显示"没卡"
    //   （cardOptions 非空）也不提示"卡不够" ⇒ 用户只能盲目关联，而**挂错卡 = 成本算错**（比不算更坏）。
    //   ⇒ 未匹配数 > 卡数时明说还差几道菜，并给出去建卡的入口。
    const shortCardGap = unmatched.length - (cardOptions || []).length;
    const shortCardText = shortCardGap > 0
      ? String(TERMS.card.reviewMapShortCard).replace('{n}', String(shortCardGap))
      : '';

    // ===== R264：覆盖率明示 =====
    //   为什么必须有：真机 51 道菜 / 3 张卡，界面只说"未匹配 51 道" ⇒ 用户既看不到"已算出几道"，
    //   也无从判断"先建哪道最划算"，面对长清单无从下手 ⇒ 这是李老师当场卡住的**同一个根因**。
    //   🔴 覆盖率按**金额**算，不按行数：真表里有 43 份 0 元的「口味询问类 SKU」，
    //      按行数算会把它们计入分母 ⇒ 覆盖率被稀释，且不能反映"钱有没有算到"。
    //   🔴 道数按**菜名去重**：同一道菜会出现在堂食 + 多个外卖平台，按行加总会把一道菜数成三道。
    // 🔴 R299（缺陷 D1）：道数去重**必须按 `dishKey`（菜品身份）**，两侧同一命名空间。
    //   改动前用的是 `.name`，而 `.name` 在两类行上语义不同：
    //     · 已匹配行 `service.js:95` ⇒ `card.name || dishKey`（**成本卡名**）
    //     · 未匹配行 `service.js:86` ⇒ `dishKey`（**菜名**）
    //   ⇒ 多张菜挂同一张卡时「共 N 道」少算；卡名与某未匹配菜名碰巧同名时两个数一起错。
    //   服务端**本来就返回** `dish_key`，是前端 discard 掉了 ⇒ 零云端改动的纯前端修复。
    const sumFen = (arr) => (arr || []).reduce((s, x) => s + (Number(x.amountFen) || 0), 0);
    let rankedFen = sumFen(dineIn);
    const dishKeys = new Set();
    dineIn.forEach((x) => dishKeys.add(x.dishKey));
    (takeaway || []).forEach((b) => {
      rankedFen += sumFen(b.ranked);
      (b.ranked || []).forEach((x) => dishKeys.add(x.dishKey));
    });
    const unmatchedFen = unmatchedSorted.reduce((s, x) => s + (Number(x.amountFen) || 0), 0);
    unmatched.forEach((x) => dishKeys.add(x.dishKey));
    const coverageCount = dishKeys.size;
    // ⚠️ 保留原公式语义（共 = 两侧并集；已算 = 共 − 未匹配数），**只统一命名空间**。
    //   跨平台「同一道菜在堂食已匹配、在外卖未匹配」会被记为「未算全」—— 改动前即如此，本轮不改（已登记）。
    const unmatchedKeys = new Set(unmatched.map((x) => x.dishKey));
    const coverageMatched = coverageCount - Array.from(unmatchedKeys).filter((k) => dishKeys.has(k)).length;
    const allFen = rankedFen + unmatchedFen;
    const coveragePct = allFen > 0 ? Math.round((rankedFen * 100) / allFen) : 0;
    const coverageText = String(TERMS.card.reviewCoverage)
      .replace('{n}', String(coverageCount))
      .replace('{m}', String(coverageMatched))
      .replace('{p}', String(coveragePct));

    // ===== R272：覆盖率 C 档 + 自助餐人均食材成本（来自 getDishReview 服务端计算）=====
    //   🔴 不动上面 A 档 coverageText（守卫 12-③/12-⑤ 钉死）：A 档分母含零售+自助会稀释，
    //      故另立 C 档（分母剔零售、自助计分子）作主口径；自助餐单列「人均食材成本」块。
    const covC = d.coverageC || {};
    const bf = d.buffet || {};
    const buffetMeals = bf.meals || 0;
    const coverageC_pct = covC.pct || 0;
    const coverageCText = String(TERMS.card.reviewCoverageC)
      .replace('{p}', String(coverageC_pct))
      .replace('{made}', fmtYuan(covC.matchedMadeRevenueFen || 0))
      .replace('{total}', fmtYuan((covC.madeRevenueFen || 0) + (covC.buffetRevenueFen || 0)))
      .replace('{retail}', fmtYuan(covC.retailRevenueFen || 0));
    const buffet_revenueText = fmtYuan(bf.revenueFen || 0);
    const buffet_perCapitaPriceText = fmtYuan(bf.perCapitaPriceFen || 0);
    const buffet_perCapitaCostText = fmtYuan(bf.perCapitaCostFen || 0);
    const buffet_grossMarginText = (bf.grossMarginPct != null) ? (String(bf.grossMarginPct) + '%') : '';
    const buffet_hasCostInput = !!bf.hasCostInput;
    // R272b：行业基准带（来自 getDishReview 服务端 benchmark）
    const bm = bf.benchmark || {};
    const buffet_benchLowText = fmtYuan(bm.costLowFen || 0);
    const buffet_benchMidText = fmtYuan(bm.costMidFen || 0);
    const buffet_benchHighText = fmtYuan(bm.costHighFen || 0);
    const buffet_rateLowPct = bm.rateLowPct || 0;
    const buffet_rateMidPct = bm.rateMidPct || 0;
    const buffet_rateHighPct = bm.rateHighPct || 0;
    // 🔴 R298：只认云端回的**机器码**（'' | high | low | ok）—— 不再用中文字面量比较。
    //   旧写法 `bm.actualFlag === '偏高'`：云端一改文案，警示色会**静默丢失**（老板看不到告警）。
    //   文案走术语单源 `TERMS.card.buffetFlag`；色号在页面层（同一张码表，两处只共享"码"这个契约）。
    const buffet_flagCode = bm.actualFlagCode || '';
    const buffet_flagText = TERMS.card.buffetFlag[buffet_flagCode] || '';
    const buffet_actualRateText = (bm.actualRatePct != null)
      ? (bm.actualRatePct + '%' + (buffet_flagText ? '（' + buffet_flagText + '）' : '')) : '';
    const BUFFET_FLAG_CLS = { high: 'warn', low: 'note' };
    const buffet_flagClass = BUFFET_FLAG_CLS[buffet_flagCode] || '';

    // A8：免费档「共 N 道已建卡，本榜只显示前 10 道」—— 让老板自己看出还差多少没看到
    //   （N ≤ 10 时不显示：数字一样，说了等于重复，只会显得啰嗦）
    const freeMoreText = (isFree && (d.free_ranked_total || 0) > 10)
      ? String(TERMS.card.reviewFreeMore).replace('{n}', String(d.free_ranked_total))
      : '';

    this.setData({
      loading: false,
      locked: false,
      // A8：'free' = 只给销量榜 + 覆盖率 + 未匹配；'full' = 完整毛利排行
      tier: isFree ? 'free' : 'full',
      freeRankedTotal: (d && d.free_ranked_total) || 0,
      freeMoreText,
      rangeText,
      dineIn,
      takeaway,
      unmatched,
      totals,
      shortCardGap,
      shortCardText,
      // R264：覆盖率
      coverageCount,
      coverageMatched,
      coveragePct,
      coverageText,
      // R272：覆盖率 C 档 + 自助餐人均食材成本
      coverageC_pct,
      coverageCText,
      // 🔴 R297-⑥（审计 M3-B3）：本页 wxml 的自助餐一族键名**一律 `buffet_xxx`**，只有这一个原先是驼峰
      //   （`buffetMeals`）⇒ `index.wxml:50` 的 `wx:if="{{buffet_meals > 0}}"` 拿到的是 `undefined`
      //   ⇒ 恒 false ⇒「人均食材成本 + 行业基准带 + 实际成本率」**整块永不渲染**（R272 专门做的能力，静默空转）。
      //   ⚠️ R272 那轮把 `t.reviewBuffet*` 文案补齐了、却没对上**数据键** ⇒ 症状从"文字空白"变成"整块不见"，更难被发现。
      buffet_meals: buffetMeals,
      buffet_revenueText,
      buffet_perCapitaPriceText,
      buffet_perCapitaCostText,
      buffet_grossMarginText,
      buffet_hasCostInput,
      // R272b：行业基准带
      buffet_benchLowText,
      buffet_benchMidText,
      buffet_benchHighText,
      buffet_rateLowPct,
      buffet_rateMidPct,
      buffet_rateHighPct,
      buffet_actualRateText,
      buffet_flagClass,
      // R255：卡列表 + 已关联列表（picker 与解除入口的数据源）
      cardOptions,
      cardCodes,
      mappings,
      decision,
      empty: dineIn.length === 0 && unmatched.length === 0 && !takeaway,
      // R260：批量模式开着时，刷新后重新算建议（已挂上的菜会消失，剩下的重算）
      batchCount: this.data.batchMode ? this.countBatchSel(unmatched) : 0,
    });
    this.markRows();
    // R252：账单列表**单独一次调用**（读侧独立函数；失败不影响复盘主区渲染）
    await this.loadBills();
  },

  // ===== R299：数据截断（可见降级）==========
  //   为什么单立一个方法：复盘 / 成本卡 / 账单是**三次独立读取**，任一处被服务端标记
  //   `truncated` 都意味着"屏幕上看到的可能不全" ⇒ 只要有一处，就显示提示。
  //   用 `_trunc` 而不是三处各写一次 `setData({truncated})` —— 否则后一次读取会把前一次的
  //   标记**覆盖掉**（三处互相冲掉 = 提示时有时无，比不提示更难查）。
  _setTrunc(source, truncated) {
    this._trunc = this._trunc || {};
    this._trunc[source] = !!truncated;
    const any = Object.keys(this._trunc).some((k) => this._trunc[k]);
    if (any !== this.data.truncated) this.setData({ truncated: any });
  },

  // ===== R307：占比拆分参考榜（估算 · 仅在空态）=====
  // 🔴 为什么在空态：实测销量拿不到时这是唯一能让 M3「打开就有东西看」的路；
  //   放在空态 ⇒ **天然不与实测榜混排**（R306 铁律①），不用额外做互斥逻辑。

  async onSplitOpen() {
    const next = !this.data.splitOpen;
    this.setData({ splitOpen: next });
    // 懒加载：只有真打开才去读 M1（避免每次进页多一次云调用）
    if (!next || this.data.splitHasOrder) return;
    const n = await this.fetchOrderCount();
    this.setData({ splitOrderCount: n, splitHasOrder: n > 0 });
  },

  /** 本月外卖有效订单数（M1 已落库的 `sub_items[].qty`，与 R302「到手账」同一取法） */
  async fetchOrderCount() {
    try {
      const d = await api.call('getLedger', { month: this.data.month });
      let n = 0;
      for (const it of (d.income_items || [])) {
        if (!it || it.category !== 'takeaway') continue;
        for (const si of (it.sub_items || [])) n += Number(si && si.qty) || 0;
      }
      return n;
    } catch (e) {
      return 0;   // 读不到 ⇒ 当"没填"处理，页面会让他去补（**不编 0 单**）
    }
  },

  // R606-bis：行为行级可编辑循环提供稳定身份键（不随数组重排/重赋值而漂），
  // 原生 <input> 按下标复用 DOM ⇒ 位置键会导致「框填不进/丢焦点」。rid 仅渲染层用。
  onSplitAdd() {
    const rows = (this.data.splitRows || []).slice();
    if (rows.length >= MAX_ROWS) return;
    rows.push(ensureRid({ cardIdx: -1, name: '', pctText: '' }));
    // 改了输入 ⇒ 旧结果作废（防"结果区还显示上一次的数"）
    this.setData({ splitRows: rows, splitResult: null, splitErr: '' });
  },

  onSplitDel(e) {
    const i = Number(e.currentTarget.dataset.idx);
    const rows = (this.data.splitRows || []).slice();
    rows.splice(i, 1);
    this.setData({ splitRows: rows, splitResult: null, splitErr: '' });
  },

  onSplitPick(e) {
    const i = Number(e.currentTarget.dataset.idx);
    const rows = (this.data.splitRows || []).slice();
    const ci = Number(e.detail.value);
    const card = (this.data.splitCards || [])[ci] || {};
    // ⚠️ 选重了**不自动去重**（静默改用户输入更糟）⇒ 交给 checkShares 报 `dupCard`
    // R606-bis：用 Object.assign 保留原行的 rid（否则整行重建会丢稳定键 ⇒ 输入框错位）
    rows[i] = Object.assign({}, rows[i], { cardIdx: ci, name: card.name || '', pctText: rows[i].pctText || '' });
    this.setData({ splitRows: rows, splitResult: null, splitErr: '' });
  },

  onSplitPct(e) {
    const i = Number(e.currentTarget.dataset.idx);
    const rows = (this.data.splitRows || []).slice();
    rows[i] = Object.assign({}, rows[i], { pctText: e.detail.value });
    this.setData({ splitRows: rows, splitResult: null, splitErr: '' });
  },

  onSplitCalc() {
    const rows = (this.data.splitRows || []).map((r) => {
      const c = (this.data.splitCards || [])[r.cardIdx] || {};
      return { cardCode: c.code || '', name: c.name || '', priceFen: c.priceFen, costFen: c.costFen, pctText: r.pctText };
    });
    const res = splitRank({ orderCount: this.data.splitOrderCount, rows });
    const T = this.data.t;
    if (res.needOrderCount) { this.setData({ splitResult: null, splitErr: T.splitNoOrder }); return; }
    if (res.errors.length) {
      const map = {
        noRows: T.splitErrNoRows, dupCard: T.splitErrDup, pctInvalid: T.splitErrPct,
        pctOver: T.splitErrPct, pctSumOver: T.splitErrSum, noPrice: T.splitErrNoPrice,
      };
      const msgs = res.errors.map((c) => map[c]).filter((x) => !!x);
      this.setData({ splitResult: null, splitErr: msgs.join('；') });
      return;
    }
    const list = (res.list || []).map((x) => ({
      name: x.name,
      sharePct: x.sharePct,
      qtyText: qtyText(x.estQty),
      unitGrossText: api.fenToYuan(x.unitGrossFen, 2),
      contribText: api.fenToYuan(x.contribFen, 2),
      // 亏损菜**必须原样露出**（负号 + 标记），不许显示成 0 或省略
      loss: x.loss,
      neg: x.contribFen < 0,
    }));
    this.setData({
      splitErr: '',
      splitResult: {
        list,
        totalPctText: String(res.totalPct),
        sumQtyText: qtyText(res.sumEstQty),
        sumContribText: api.fenToYuan(res.sumContribFen, 2),
        sumNeg: res.sumContribFen < 0,
      },
    });
  },

  // ===== R255：成本卡列表（供「关联」picker 用）=====
  //   复用既有 `getCostCard({})`（出参 list[] = 该店各卡的最新版本），**不新增读接口**。
  //   🔴 失败不阻断：卡列表拉不到 ⇒ 只影响「关联」入口（数组置空 ⇒ picker 不渲染），
  //      复盘主区照常渲染 —— 附加载荷不该拖垮主功能（与 loadBills 同一条纪律）。
  async loadCards() {
    try {
      const res = await api.call('getCostCard', {});
      const list = (res && res.list) || [];
      const byCode = new Map();
      for (const c of list) {
        const cc = c.card_code;
        if (!cc) continue;
        const cur = byCode.get(cc);
        if (!cur || (Number(c.version) || 0) > (Number(cur.version) || 0)) byCode.set(cc, c);
      }
      const codes = Array.from(byCode.keys());
      const nameByCode = {};
      const cardOptions = codes.map((cc) => {
        const nm = byCode.get(cc).name || cc;
        nameByCode[cc] = nm;
        return nm;
      });
      // 🔴 R299：把 `truncated` **带出去**（由调用方统一汇总显示，见 _setTrunc）。
      //   卡少了 ⇒ picker 选项少 ⇒ 用户明明有卡却挂不上，且零提示（静默少卡）。
      // 🔴 R307：同时派生 `splitCards`（占比估算用）—— **同一次读、不新增接口**。
      //   售价/成本取该卡**最新版本**（byCode 已按 version 取大）；缺值按 0（后面 `checkShares` 会拦 `noPrice`）。
      const splitCards = codes.map((cc) => {
        const c = byCode.get(cc) || {};
        return {
          code: cc,
          name: nameByCode[cc] || cc,
          priceFen: Number(c.price_fen) || 0,
          costFen: Number(c.total_cost_fen) || 0,
        };
      });
      return { cardCodes: codes, cardOptions, nameByCode, splitCards, truncated: dh.isTruncated(res) };
    } catch (e) {
      return { cardCodes: [], cardOptions: [], nameByCode: {}, splitCards: [], truncated: false };
    }
  },

  // ===== R255：把未匹配菜名**关联**到成本卡 =====
  //   🔴 键口径（与读侧 lookupCardCode 对齐，错位 = 挂了也读不到、静默失效）：
  //     · `dish_key` = **原始菜名**（不归一 —— 读侧按原样查）；
  //     · `platform` **不传**（空 ⇒ 跨所有平台生效，读侧有 mapIndex.get('|' + k) 兜底）。
  async onPickCard(e) {
    if (this.data.mappingBusy) return;
    const pick = Number(e.detail.value);
    const rowIdx = Number(e.currentTarget.dataset.idx);
    const row = this.data.unmatched[rowIdx];
    const cardCode = this.data.cardCodes[pick];
    if (!row || !cardCode) return;
    this.setData({ mappingBusy: true });
    try {
      await api.call('saveDishMapping', { dish_key: row.dishKey, card_code: cardCode });
      wx.showToast({ title: TERMS.card.reviewMapOk, icon: 'none' });
      await this.load();   // 重算：该菜应从 unmatched 变 ranked
    } catch (err) {
      api.toastError(err);
    } finally {
      this.setData({ mappingBusy: false });
    }
  },

  // ===================== R260：批量关联（规范 v1.9）=====================
  // 现状痛点（实测）：R255 的入口是「一道菜一次 picker + 选完 `await this.load()` 重算整页」
  //   ⇒ 51 道外卖菜 = 51 次全页往返。批量把往返压成 ⌈N/BATCH_CHUNK⌉ 次。
  // 🔴 三条不可动摇（规范 v1.9 D29/D30/D32）：
  //   ① 行的选择**只记在本机**（选择路径内**不得**调 saveDishMapping）；
  //   ② 建议**只预选**，绝不自动提交（归一化匹配必然会误判，如"来点辣椒?吗"这类口味询问 SKU）；
  //   ③ 提交载荷只来自**用户确认后的选择集**（selCode），不回读建议函数的返回值。

  // 给未匹配行算「建议卡」（只预选；`how` 用于在界面上标「建议」二字）
  applyBatchSuggestions(rows) {
    const names = this.data.cardOptions || [];
    const codes = this.data.cardCodes || [];
    return (rows || []).map((x) => {
      const s = suggestCardIndex(x.name, names);
      const sel = s.index >= 0 && codes[s.index] ? codes[s.index] : '';
      return Object.assign({}, x, {
        pickIdx: s.index >= 0 ? s.index : 0,
        selCode: sel,
        selLabel: sel ? names[s.index] : '',
        suggestHow: sel ? s.how : '',
      });
    });
  },

  countBatchSel(rows) {
    return (rows || []).filter((x) => x.selCode).length;
  },

  onToggleBatch() {
    if (this.data.batchSaving) return;
    if (this.data.batchMode) { this.setData({ batchMode: false, batchCount: 0 }); return; }
    if (!this.data.cardOptions.length) { api.say(TERMS.card.reviewMapNoCard); return; }
    const rows = this.applyBatchSuggestions(this.data.unmatched);
    this.setData({ batchMode: true, unmatched: rows, batchCount: this.countBatchSel(rows) });
  },

  // 行内选择：**只改本地**（不调云函数、不重载整页）
  onPickLocal(e) {
    if (this.data.batchSaving) return;
    const idx = Number(e.currentTarget.dataset.idx);
    const pick = Number(e.detail.value);
    const code = (this.data.cardCodes || [])[pick];
    if (!code) return;
    const rows = this.data.unmatched.slice();
    if (!rows[idx]) return;
    rows[idx] = Object.assign({}, rows[idx], {
      pickIdx: pick, selCode: code, selLabel: this.data.cardOptions[pick],
      // 用户改过 ⇒ 不再是"建议"（界面上的「建议」标记随之消失，避免误导"这是系统推荐的"）
      suggestHow: '',
    });
    this.setData({ unmatched: rows, batchCount: this.countBatchSel(rows) });
  },

  // 行内清掉本地选择（保留本行在未匹配清单里，稍后再选）
  onClearLocal(e) {
    if (this.data.batchSaving) return;
    const idx = Number(e.currentTarget.dataset.idx);
    const rows = this.data.unmatched.slice();
    if (!rows[idx]) return;
    rows[idx] = Object.assign({}, rows[idx], { selCode: '', selLabel: '', suggestHow: '' });
    this.setData({ unmatched: rows, batchCount: this.countBatchSel(rows) });
  },

  // 一次提交（分块 ≤ BATCH_CHUNK；上限的硬约束在云端 MAX_BATCH，守卫钉住两者关系）
  async onSaveBatch() {
    if (this.data.batchSaving) return;
    const items = this.data.unmatched
      .filter((x) => x.selCode)
      .map((x) => ({ dish_key: x.dishKey, card_code: x.selCode }));
    if (!items.length) { wx.showToast({ title: TERMS.card.reviewBatchNone, icon: 'none' }); return; }
    this.setData({ batchSaving: true });
    wx.showLoading({ title: TERMS.card.reviewBatchSaving });
    let done = 0;
    try {
      for (let i = 0; i < items.length; i += BATCH_CHUNK) {
        const chunk = items.slice(i, i + BATCH_CHUNK);
        await api.call('saveDishMapping', {
          items: chunk,
          client_request_id: 'dm_' + Date.now() + '_' + i,
        });
        done += chunk.length;
        wx.showLoading({ title: TERMS.card.reviewBatchSaving + ' ' + done + '/' + items.length });
      }
      wx.hideLoading();
      wx.showToast({ title: TERMS.card.reviewBatchDone + ' ' + done, icon: 'success' });
      // 重算：已挂上的菜从候选里消失、剩下的重新给建议（batchMode 保持开启，便于继续）
      await this.load();
    } catch (err) {
      wx.hideLoading();
      api.toastError(err);
    } finally {
      this.setData({ batchSaving: false });
    }
  },

  // ===== R255：**解除**已关联（card_code 传空串即解除）=====
  async onUnlinkMap(e) {
    if (this.data.mappingBusy) return;
    const rowIdx = Number(e.currentTarget.dataset.idx);
    const m = this.data.mappings[rowIdx];
    if (!m) return;
    this.setData({ mappingBusy: true });
    try {
      await api.call('saveDishMapping', { dish_key: m.dishKey, card_code: '' });
      wx.showToast({ title: TERMS.card.reviewMapUnlinkOk, icon: 'none' });
      await this.load();
    } catch (err) {
      api.toastError(err);
    } finally {
      this.setData({ mappingBusy: false });
    }
  },

  // ===== R252：已导入账单（查看 + 清除）=====
  //   为什么单独一次调用：`getSalesBills` 与 `getDishReview` 是两个读侧函数
  //   （一个列"导过什么"、一个算"毛利多少"）。分开 ⇒ 账单区失败不拖垮复盘主区。
  async loadBills() {
    try {
      const res = await api.call('getSalesBills', {});
      const names = TERMS.card.reviewPlatformNames;
      const bills = (res.list || []).map((x) => ({
        bill_id: x.bill_id,
        kind: x.kind,
        kindText: x.kind === 'bill' ? TERMS.card.reviewBillsBill : TERMS.card.reviewBillsDish,
        platform: x.platform,
        platformText: names[x.platform] || x.platform,
        bizDate: x.biz_date,
        rowCount: x.row_count,
        qtyText: String(x.qty),
        amountText: fmtYuan(x.amount_fen),
        cleared: !!x.cleared,
      }));
      this.setData({ bills, billsSummary: res.summary || null });
      // 🔴 R299（缺陷 D2）：账单列表是所有已导入账单的"账"，少行 = 用户以为没导过 ⇒ 同样必须可见降级。
      //   ⚠️ `getSalesBills` 的 `truncated` 判据与其它函数**不同源**（它用 `>= LIST_LIMIT`，
      //      见 `cloudfunctions/getSalesBills/index.js:41-44` 注释），但出参字段名相同 ⇒ 谓词通用。
      this._setTrunc('bills', dh.isTruncated(res));
    } catch (e) {
      // 账单区是"附加信息"：失败就留空，不 toast（复盘主区已渲染，不该被它打断）
      this.setData({ bills: [], billsSummary: null });
      this._setTrunc('bills', false);
    }
  },

  // 清除单条（二次确认 → clearSalesBills({targets}) → 刷新账单区 + 复盘主区）
  onClearBill(e) {
    const idx = Number(e.currentTarget.dataset.idx);
    const b = this.data.bills[idx];
    if (!b) return;
    wx.showModal({
      title: TERMS.card.reviewBillsClear,
      content: TERMS.card.reviewBillsClearConfirm,
      confirmColor: '#e74c3c',
      success: (r) => {
        if (!r.confirm) return;
        this.doClear([{ platform: b.platform, biz_date: b.bizDate, kind: b.kind }], false);
      },
    });
  },

  // 全部清除（二次确认 → clearSalesBills({all,confirm_all}) ）
  onClearAllBills() {
    if (!this.data.bills.length) {
      wx.showToast({ title: TERMS.card.reviewBillsClearedNone, icon: 'none' });
      return;
    }
    wx.showModal({
      title: TERMS.card.reviewBillsClearAll,
      content: TERMS.card.reviewBillsClearAllConfirm,
      confirmColor: '#e74c3c',
      success: (r) => {
        if (!r.confirm) return;
        this.doClear([], true);
      },
    });
  },

  async doClear(targets, all) {
    if (this.data.clearing) return;         // 防连点（同一动作并发 = 幂等键之外的第二道闸）
    this.setData({ clearing: true });
    try {
      const req = { shop_id: (getApp().globalData && getApp().globalData.shop_id) || '' };
      if (all) { req.all = true; req.confirm_all = true; } else { req.targets = targets; }
      await api.call('clearSalesBills', req);
      wx.showToast({ title: TERMS.card.reviewBillsClearedToast, icon: 'success' });
      // 清除后**两个区都要刷**：账单区（行消失/标已清除）+ 复盘主区（数字自然不含被清的行）
      await this.loadBills();
      await this.load();
    } catch (e) {
      api.toastError(e);
    } finally {
      this.setData({ clearing: false });
    }
  },

  // 阈值变化 → 重标红（仅提示，不影响任何计算口径）
  // ===== R281 O2：首屏重构 —— 折叠区开关 =====
  toggleMore() { this.setData({ moreOpen: !this.data.moreOpen }); },
  toggleData() { this.setData({ dataOpen: !this.data.dataOpen }); },

  // 🔴 R301：切「统计月份」⇒ 按新区间重新取数。用 `<picker mode="date" fields="month">`
  //   （系统选择器、**零新术语/零新数据源**），值是 `YYYY-MM`。
  //   只读页 ⇒ 直接重载，无未保存输入可丢（与 onShow 返回刷新同一条依据）。
  onMonth(e) {
    const m = (e && e.detail && e.detail.value) || '';
    if (!m || m === this.data.month) return;
    this.setData({ month: m });
    this.load();
  },

  // 顶部红色待办条「去挂」⇒ 直接滚到未匹配区（不新增页面、不跳走，免得打断看榜）
  gotoUnmatched() {
    wx.pageScrollTo({ selector: '#unmatched', duration: 200 });
  },

  onThreshold(e) {
    const raw = e.detail.value;
    const n = Number(raw);
    this.setData({
      thresholdInput: raw,
      threshold: isFinite(n) && n >= 0 ? n : 0,
    });
    this.markRows();
  },

  markRows() {
    const th = this.data.threshold;
    const dineIn = this.data.dineIn.map((x) => Object.assign({}, x, { below: x.marginPct < th }));
    const takeaway = this.data.takeaway
      ? this.data.takeaway.map((b) => Object.assign({}, b, {
          ranked: b.ranked.map((x) => Object.assign({}, x, { below: x.marginPct < th })),
        }))
      : null;
    this.setData({ dineIn, takeaway });
  },

  // 「去映射」= 去建缺失的成本卡（未匹配菜品没有对应卡 ⇒ 建了卡即自动匹配）
  goMap() { wx.navigateTo({ url: '/subpkg/biz/card/index' }); },

  // ===== R264：带着菜名去建卡（**预填**）=====
  //   原路径：退出复盘 → M3 → 菜品卡 → 新建 → 手打菜名。51 道菜来回切，最容易错的就是菜名
  //   （打错一个字 = 建了另一道菜的卡，回来照样匹配不上 ⇒ 白建一张）。
  //   ⇒ 直接跳建卡页并把菜名带上（`subpkg/biz/card/edit` 的 onLoad 负责回填）。
  //   🔴 菜名必须 `encodeURIComponent`：菜名里有空格/括号/加号（如「肥牛(大)」「A+B 套餐」），
  //      不编码会被 URL 截断或把 `+` 解成空格 ⇒ 预填出来是错的名字（静默错）。
  goNewCard(e) {
    const nm = (e && e.currentTarget && e.currentTarget.dataset && e.currentTarget.dataset.name) || '';
    wx.navigateTo({ url: '/subpkg/biz/card/edit?card_code=&dish_name=' + encodeURIComponent(nm) });
  },
});
