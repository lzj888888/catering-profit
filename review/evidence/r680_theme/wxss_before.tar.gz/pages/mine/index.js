// pages/mine/index.js —— 批次 7 · 「我的」页（隐私协议 + 撤回授权 + 账号注销）
//
// ⚠️ 隐私合规（§2.10）：隐私协议查看 + 撤回授权入口；
// ⚠️ 账号注销（§2.11）：二次确认 → 调 deleteAccount（软删 user + 匿名化 PII）→ 清本地缓存退出。
const api = require('../../utils/api.js');
const ui = require('../../utils/ui.js');
const loading = require('../../utils/loading.js');
const { TERMS } = require('../../miniprogram/i18n/terms.js');
const shopGuard = require('../../utils/shopGuard.js');

Page({
  data: {
    t: {
      title: TERMS.exp.mineTitle,
      account: TERMS.exp.account,
      logoutTitle: TERMS.exp.logoutTitle,
      logoutConfirm: TERMS.exp.logoutConfirm,
      logoutDone: TERMS.exp.logoutDone,
      cancelLogout: TERMS.exp.cancelLogout,
      privacyOpen: TERMS.exp.privacyOpen,
      privacyRevoke: TERMS.exp.privacyRevoke,
      privacyRevoked: TERMS.exp.privacyRevoked,
      privacyDesc: TERMS.exp.privacyDesc,
      privacyTitle: TERMS.exp.privacyTitle,
      dataCleanNote: TERMS.exp.dataCleanNote,
      cancel: TERMS.buttons.cancel,
      shopName: TERMS.ui.shopName,
      goSetting: TERMS.exp.goSetting,
      // C1：关于 / 版本 / 意见反馈 / 免责声明
      about: TERMS.exp.about,
      versionLabel: TERMS.exp.versionLabel,
      appVersion: TERMS.exp.appVersion,
      feedback: TERMS.exp.feedback,
      feedbackHint: TERMS.exp.feedbackHint,
      // R193：站级兜底入口（订单 / 客服 / 使用指引）
      ordersEntry: TERMS.exp.ordersEntry,
      serviceEntry: TERMS.exp.serviceEntry,
      guideEntry: TERMS.exp.guideEntry,
      guideBody: TERMS.exp.guideBody,
      guideOk: TERMS.exp.guideOk,
      disclaimerLabel: TERMS.exp.disclaimerLabel,
      aiConsentLabel: TERMS.exp.aiConsentLabel,
      disclaimer: TERMS.auditSafe.disclaimer,
      // G5：头像昵称（AD-15 新能力，本地保存展示）
      avatarLabel: TERMS.exp.avatarLabel,
      nicknameLabel: TERMS.exp.nicknameLabel,
      nicknamePh: TERMS.exp.nicknamePh,
      avatarSaved: TERMS.exp.avatarSaved,
    },
    shopName: '',
    avatarUrl: '',
    nickname: '',
    loadingLogout: false,
  },

  // 🔴 R215：本页是 tabBar 页 ⇒ 冷启动直达时补拉店铺上下文（无店铺态会弹引导并返回 null）。
  //   取 shop_name 前必须先 await，否则读到的是空 globalData（表现为「店铺名空白」）。
  async onShow() {
    ui.setTitle(TERMS.exp.mineTitle);
    try { await shopGuard.ensureShop(); } catch (e) { /* 静默：本页其余入口不依赖上下文 */ }
    const app = getApp();
    this.setData({
      shopName: (app.globalData && app.globalData.shop_name) || '',
      avatarUrl: wx.getStorageSync('user_avatar') || '',
      nickname: wx.getStorageSync('user_nickname') || '',
    });
  },

  // G5：头像选择（新能力 chooseAvatar，不用 getUserProfile）
  onChooseAvatar(e) {
    const url = e.detail && e.detail.avatarUrl;
    if (!url) return;
    this.setData({ avatarUrl: url });
    wx.setStorageSync('user_avatar', url);
  },
  // G5：昵称输入（新能力 input type=nickname）
  onNickname(e) {
    const v = e.detail && e.detail.value;
    if (v === undefined || v === null) return;
    this.setData({ nickname: v });
    wx.setStorageSync('user_nickname', v);
  },

  // C1：意见反馈（AD-16 客服入口）
  onFeedback() {
    if (wx.openFeedback) {
      wx.openFeedback({});
    } else {
      wx.showToast({ title: TERMS.exp.feedbackHint, icon: 'none' });
    }
  },

  // R193：我的订阅 / 订单 —— 此前 pay/orders 只能从「到期提醒条 / 月列表 / 成本卡列表」进，
  //   已付费用户在「我的」里根本找不到自己的有效期与续费入口（提醒条只在快到期才出现）。
  goOrders() { wx.navigateTo({ url: '/subpkg/tools/pay/orders' }); },

  // R193：使用指引 —— 新用户打开就是四张卡，M1 要填 40+ 字段，没有"第一次怎么用"。
  // 🔴 showModal confirmText ≤4 字符（文案已按此约束给「知道了」）。
  onGuide() {
    wx.showModal({
      title: TERMS.exp.guideEntry,
      content: TERMS.exp.guideBody,
      showCancel: false,
      confirmText: TERMS.exp.guideOk,
      confirmColor: '#1e3a5f',
    });
  },

  // C1：免责声明弹窗
  // R434（队列 #29）：AI 辅助分析授权页
  onAiConsent() {
    wx.navigateTo({ url: '/subpkg/biz/ai/consent' });
  },

  onDisclaimer() {
    wx.showModal({
      title: TERMS.exp.disclaimerLabel,
      content: TERMS.auditSafe.disclaimer,
      showCancel: false,
      confirmText: TERMS.buttons.thinkAgain || '知道了',
      confirmColor: '#1e3a5f',
    });
  },

  // 查看隐私协议
  onOpenPrivacy() {
    wx.showModal({
      title: TERMS.exp.privacyTitle,
      content: TERMS.exp.privacyDesc,
      showCancel: false,
      confirmText: TERMS.buttons.thinkAgain || '知道了',
      confirmColor: '#1e3a5f',
    });
  },

  // 撤回授权：调 wx.requirePrivacyAuthorize? 实际「撤回」用 wx.openPrivacyContract + 引导去设置；
  // 小程序侧撤回=引导到「设置」取消隐私授权（wx.openSetting）。展示入口即可。
  onRevokePrivacy() {
    wx.showModal({
      title: TERMS.exp.privacyRevoke,
      content: TERMS.exp.privacyRevoked,
      confirmText: TERMS.exp.goSetting,
      cancelText: TERMS.buttons.cancel,
      confirmColor: '#1e3a5f',
      success(res) {
        if (res.confirm) wx.openSetting({});
      },
    });
  },

  // 注销账号（二次确认 + loading + 防重复提交 + 幂等）
  onLogout() {
    wx.showModal({
      title: TERMS.exp.logoutTitle,
      content: TERMS.exp.logoutConfirm,
      confirmText: TERMS.exp.logoutTitle,
      cancelText: TERMS.exp.cancelLogout,
      confirmColor: '#e74c3c',
      success: (r) => {
        if (r.confirm) this.doLogout();
      },
    });
  },

  async doLogout() {
    await loading.withLock(this, 'logout', async () => {
      try {
        // G6：注销为不可逆操作 → 触觉反馈
        if (wx.vibrateShort) { try { wx.vibrateShort({ type: 'medium' }); } catch (err) { /* 部分机型不支持，忽略 */ } }
        await api.call('deleteAccount', { client_request_id: 'acc_' + Date.now() });
        // 清本地缓存 + 退出
        wx.clearStorageSync();
        const app = getApp();
        if (app && app.globalData) {
          // R215：登出后会话标志必须一起清 —— 否则下次进入时 ensureShop 命中「已加载」
          //   而返回上一账号的上下文（跨账号串档）。
          app.globalData.shop_id = '';
          app.globalData.shop_name = '';
          app.globalData.shopLoaded = false;
          app.globalData.no_shop = false;
          app.globalData.noShopPrompted = false;
        }
        api.say(TERMS.exp.logoutDone);
        // 🔴 R199：`pages/index/index` 已改为**底部 tabBar 页** ⇒ `wx.reLaunch` 到 tabBar 页会失败
        //   （微信限制：tabBar 页只能 `switchTab`）。登出后回首页同样用 `wx.switchTab`。
        setTimeout(() => wx.switchTab({ url: '/pages/index/index' }), 1200);
      } catch (e) {
        api.toastError(e);
      }
    });
  },

  onPullDownRefresh() { this.onShow().then(() => wx.stopPullDownRefresh()); },
});